import redis
import json

r = redis.Redis(host='redis', port=6379, decode_responses=True)

def store_event(event):
    r.set(f"event:{event['id']}", json.dumps(event))

def get_event(event_id):
    data = r.get(f"event:{event_id}")
    return json.loads(data) if data else None
