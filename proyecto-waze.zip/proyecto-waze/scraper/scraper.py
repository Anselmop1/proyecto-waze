import requests
import json
from storage.redis_storage import store_event

def get_waze_events():
    # Coordenadas aproximadas para la Región Metropolitana de Santiago, Chile
    params = {
        'bottom': -33.75,
        'left': -70.85,
        'top': -33.3,
        'right': -70.4,
    }

    headers = {
        'User-Agent': 'Mozilla/5.0',
        'Referer': 'https://www.waze.com/es-419/live-map/'
    }

    url = "https://www.waze.com/row-rtserver/web/TGeoRSS"

    try:
        response = requests.get(url, params=params, headers=headers, timeout=10)
        response.raise_for_status()
        data = response.json()
        print("Datos obtenidos desde Waze.")
        return data.get("alerts", []) + data.get("jams", [])
    except Exception as e:
        print(f"Error al obtener eventos de Waze: {e}")
        print("Usando eventos simulados desde storage/events.json")
        try:
            with open("storage/events.json", "r") as f:
                return json.load(f)
        except Exception as local_error:
            print(f"Error al cargar eventos locales: {local_error}")
            return []

def format_event(event):
    location_raw = event.get('location', {})
    if isinstance(location_raw, dict):
        location = location_raw.get('street', 'Desconocido')
    else:
        location = location_raw  # ya es string

    return {
        'id': event.get('uuid') or event.get('id'),
        'type': event.get('type') or event.get('jamType', 'UNKNOWN'),
        'location': location,
        'description': event.get('description', 'Sin descripción')
    }

def run_scraper():
    events = get_waze_events()
    for raw_event in events:
        event = format_event(raw_event)
        store_event(event)

if __name__ == '__main__':
    run_scraper()
