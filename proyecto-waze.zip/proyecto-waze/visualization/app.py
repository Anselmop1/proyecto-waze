from flask import Flask, jsonify
import redis
import json

app = Flask(__name__)

@app.route("/")
def index():
    try:
        r = redis.Redis(host="redis", port=6379, decode_responses=True)
        stats = r.get("stats:resumen")

        if stats:
            return jsonify(json.loads(stats))
        else:
            return jsonify({"message": "No hay datos procesados aún."}), 404

    except Exception as e:
        return jsonify({"error": f"Error al conectar con Redis: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
