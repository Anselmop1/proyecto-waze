import random
import time
from storage.redis_storage import get_event
from cache.cache import get_from_cache, save_to_cache

def poisson_arrivals(rate):
    return random.expovariate(rate)

def exponential_arrivals(rate):
    return -1 * rate * random.lognormvariate(0, 1)

def generate_traffic(n=1000, distribution='poisson'):
    for _ in range(n):
        event_id = random.randint(0, 9999)
        if get_from_cache(event_id) is None:
            event = get_event(event_id)
            if event:
                print(f"[Miss] Event {event_id}: {event['type']} - {event['location']}")
                save_to_cache(event_id, event)
        else:
            print(f"[Hit] Event {event_id} found in cache")
        wait_time = poisson_arrivals(5) if distribution == 'poisson' else exponential_arrivals(0.5)
        time.sleep(abs(wait_time))

if __name__ == '__main__':
    generate_traffic(distribution='poisson')
