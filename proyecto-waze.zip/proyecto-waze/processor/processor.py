
import redis
import json
import os
from collections import defaultdict

# Conexión a Redis
r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)

def cargar_eventos():
    eventos = []
    for key in r.scan_iter("event:*"):
        data = r.get(key)
        if data:
            eventos.append(json.loads(data))
    return eventos

def procesar(eventos):
    resumen = {
        "total_eventos": len(eventos),
        "por_tipo": defaultdict(int),
        "por_calle": defaultdict(int)
    }

    for evento in eventos:
        tipo = evento.get("type", "UNKNOWN")
        calle = evento.get("location", "Desconocida")
        resumen["por_tipo"][tipo] += 1
        resumen["por_calle"][calle] += 1

    # Convertir defaultdict a dict normal
    resumen["por_tipo"] = dict(resumen["por_tipo"])
    resumen["por_calle"] = dict(resumen["por_calle"])
    return resumen

def guardar_en_redis(stats):
    r.set("stats:resumen", json.dumps(stats, indent=2))

def guardar_en_archivo(stats):
    output_dir = os.path.join(os.path.dirname(__file__), "output")
    os.makedirs(output_dir, exist_ok=True)
    with open(os.path.join(output_dir, "stats.json"), "w") as f:
        json.dump(stats, f, indent=2)

if __name__ == "__main__":
    eventos = cargar_eventos()
    stats = procesar(eventos)
    guardar_en_redis(stats)
    guardar_en_archivo(stats)
    print("Estadísticas procesadas y guardadas en Redis y archivo.")
